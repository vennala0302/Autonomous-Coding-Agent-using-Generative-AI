from utils import ask_gemini
from prompts import REVIEW_PROMPT


def review_code(code):
    prompt = REVIEW_PROMPT.format(code=code)
    return ask_gemini(prompt)