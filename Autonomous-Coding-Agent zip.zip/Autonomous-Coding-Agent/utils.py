import os
import google.generativeai as genai
from dotenv import load_dotenv

# Load .env file
load_dotenv()

# Configure Gemini API
API_KEY = os.getenv("GEMINI_API_KEY")

if not API_KEY:
    raise ValueError("GEMINI_API_KEY not found in .env file")

genai.configure(api_key=API_KEY)

# Gemini Model
model = genai.GenerativeModel("gemini-3.5-flash-lite")


def ask_gemini(prompt):
    """
    Sends a prompt to Gemini AI and returns the response.
    """
    try:
        response = model.generate_content(prompt)

        if response and hasattr(response, "text"):
            return response.text

        return "No response generated."

    except Exception as e:
        return f"❌ Gemini Error:\n\n{str(e)}"