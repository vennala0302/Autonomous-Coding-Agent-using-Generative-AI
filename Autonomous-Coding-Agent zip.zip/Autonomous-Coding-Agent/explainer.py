from utils import ask_gemini
from prompts import EXPLAIN_PROMPT


def explain_code(code):
    prompt = EXPLAIN_PROMPT.format(code=code)
    return ask_gemini(prompt)