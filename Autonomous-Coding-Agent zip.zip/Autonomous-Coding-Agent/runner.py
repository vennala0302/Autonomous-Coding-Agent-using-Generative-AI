import io
import contextlib
import builtins
import traceback


def run_python_code(code, inputs=None):
    """
    Executes Python code and captures its output.
    """

    if inputs is None:
        inputs = []

    input_iter = iter(inputs)

    def fake_input(prompt=""):
        try:
            return next(input_iter)
        except StopIteration:
            return ""

    # Replace input() with fake input
    old_input = builtins.input
    builtins.input = fake_input

    output = io.StringIO()

    try:
        # Execute the code as a main program
        with contextlib.redirect_stdout(output):
            exec(code, {"__name__": "__main__"})

        result = output.getvalue()

        if not result.strip():
            result = "Program executed successfully. No output."

    except Exception:
        result = "Runtime Error:\n\n" + traceback.format_exc()

    finally:
        # Restore original input()
        builtins.input = old_input

    return result