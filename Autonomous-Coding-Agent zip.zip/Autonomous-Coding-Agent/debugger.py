from utils import ask_gemini
from prompts import DEBUG_PROMPT


def debug_code(code):
    prompt = DEBUG_PROMPT.format(code=code)
    return ask_gemini(prompt)
