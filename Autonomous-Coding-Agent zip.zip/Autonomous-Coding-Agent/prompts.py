# ===========================
# AI Prompt Templates
# ===========================

# Generate Code
CODE_PROMPT = """
You are an expert Software Engineer.

Generate a complete, executable {language} program for the following problem.

Problem:
{query}

Rules:
1. Return ONLY executable code.
2. Do NOT include explanations.
3. Do NOT include markdown.
4. Do NOT use triple backticks.
5. Use input() whenever user input is required.
6. Do NOT use hardcoded values like "Hello, World!" or 10.
7. Print the final result.
8. The program must be complete and executable.
"""

# Explain Code
EXPLAIN_PROMPT = """
You are an expert programming tutor.

Explain the following code in simple, easy-to-understand language.

Code:
{code}
"""

# Debug Code
DEBUG_PROMPT = """
You are an expert software debugger.

Find all bugs, logical errors, syntax errors, and possible improvements in the following code.

Return the corrected code with explanations.

Code:
{code}
"""

# Optimize Code
OPTIMIZE_PROMPT = """
You are an expert software engineer.

Optimize the following code for better readability, performance, and memory usage.

Code:
{code}
"""

# Code Review
REVIEW_PROMPT = """
You are an expert code reviewer.

Review the following code.

Mention:
- Strengths
- Weaknesses
- Best Practices
- Suggestions

Code:
{code}
"""

# Complexity Analysis
COMPLEXITY_PROMPT = """
Analyze the following code.

Provide:
- Time Complexity
- Space Complexity
- Short Explanation

Code:
{code}
"""

# Test Case Generation
TESTCASE_PROMPT = """
Generate multiple test cases for the following code.

Include:
- Normal Test Cases
- Edge Test Cases
- Invalid Test Cases (if applicable)

Code:
{code}
"""