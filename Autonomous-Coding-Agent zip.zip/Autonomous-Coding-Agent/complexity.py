from utils import ask_gemini
from prompts import COMPLEXITY_PROMPT


def analyze_complexity(code):
    prompt = COMPLEXITY_PROMPT.format(code=code)
    return ask_gemini(prompt)