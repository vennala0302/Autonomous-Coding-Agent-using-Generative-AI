from utils import ask_gemini
from prompts import TESTCASE_PROMPT


def generate_testcases(code):
    prompt = TESTCASE_PROMPT.format(code=code)
    return ask_gemini(prompt)