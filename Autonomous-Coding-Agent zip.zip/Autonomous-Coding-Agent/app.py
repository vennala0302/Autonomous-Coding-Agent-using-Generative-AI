import streamlit as st
import re

from code_generator import generate_code
from explainer import explain_code
from debugger import debug_code
from optimizer import optimize_code
from reviewer import review_code
from complexity import analyze_complexity
from test_generator import generate_testcases
from runner import run_python_code

# -----------------------------
# Page Configuration
# -----------------------------
st.set_page_config(
    page_title="AI Developer Assistant",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# -----------------------------
# Session State
# -----------------------------
if "generated_code" not in st.session_state:
    st.session_state.generated_code = ""

if "language" not in st.session_state:
    st.session_state.language = "Python"

# -----------------------------
# CSS
# -----------------------------
st.markdown("""
<style>

.main-title{
text-align:center;
font-size:45px;
font-weight:bold;
color:#4CAF50;
}

.sub-title{
text-align:center;
font-size:18px;
color:gray;
}

.footer{
text-align:center;
color:gray;
margin-top:40px;
}

</style>
""", unsafe_allow_html=True)

# -----------------------------
# Sidebar
# -----------------------------
st.sidebar.title("🤖 AI Developer Assistant")

menu = st.sidebar.radio(
    "Navigation",
    [
        "🏠 Home",
        "🤖 AI Assistant",
        "ℹ About"
    ]
)

# -----------------------------
# HOME
# -----------------------------
if menu == "🏠 Home":

    st.markdown(
        "<h1 class='main-title'>AI Developer Assistant</h1>",
        unsafe_allow_html=True
    )

    st.markdown(
        "<p class='sub-title'>Generate, Explain, Debug, Optimize and Run Python Code using Gemini AI</p>",
        unsafe_allow_html=True
    )

    c1, c2, c3 = st.columns(3)

    c1.metric("Languages", "5")
    c2.metric("AI Model", "Gemini")
    c3.metric("Features", "8")

    st.markdown("---")

    col1, col2 = st.columns(2)

    with col1:
        st.success("✅ Generate Code")
        st.success("📖 Explain Code")
        st.success("🐞 Debug Code")
        st.success("⚡ Optimize Code")

    with col2:
        st.success("🔍 AI Code Review")
        st.success("📊 Complexity Analysis")
        st.success("🧪 Test Case Generation")
        st.success("▶ Run Python Code")

# -----------------------------
# ABOUT
# -----------------------------
elif menu == "ℹ About":

    st.header("About AI Developer Assistant")

    st.write("""
This project uses Google Gemini AI to:

- Generate Code
- Explain Code
- Debug Code
- Optimize Code
- Review Code
- Analyze Complexity
- Generate Test Cases
- Run Python Code
""")
# -----------------------------
# AI ASSISTANT
# -----------------------------
elif menu == "🤖 AI Assistant":

    st.title("🤖 AI Developer Assistant")

    language = st.selectbox(
        "Programming Language",
        ["Python", "Java", "C", "C++", "JavaScript"],
        index=["Python", "Java", "C", "C++", "JavaScript"].index(
            st.session_state.language
        ),
    )

    prompt = st.text_area(
        "Describe your coding problem",
        height=180,
        placeholder="Example: Write a Python program to check whether a number is prime or not.",
    )

    # -----------------------------
    # Generate Code
    # -----------------------------
    if st.button("🚀 Generate Code"):

        if prompt.strip() == "":
            st.warning("Please enter a coding problem.")
            st.stop()

        with st.spinner("Generating Code..."):
            response = generate_code(prompt, language)

        if response.startswith("Error:"):
            st.error(response)
            st.stop()

        # Extract executable code
        match = re.search(
            r"```(?:python|java|c|cpp|javascript)?\n(.*?)```",
            response,
            re.DOTALL | re.IGNORECASE,
        )

        if match:
            st.session_state.generated_code = match.group(1).strip()
        else:
            st.session_state.generated_code = response.strip()

        st.session_state.language = language

    # -----------------------------
    # Display Generated Code
    # -----------------------------
    if st.session_state.generated_code:

        code = st.session_state.generated_code
        language = st.session_state.language

        st.success("✅ Code Generated Successfully")

        st.subheader("💻 Generated Code")
        st.code(code, language=language.lower())

        # -----------------------------
        # Run Python Code
        # -----------------------------
        if language == "Python":

            st.subheader("▶ Run Python Code")

            user_inputs = st.text_area(
                "Enter program inputs (one input per line)",
                placeholder="Example:\n10\n20",
            )

            if st.button("▶ Execute Program"):

                input_list = user_inputs.splitlines()

                with st.spinner("Running Program..."):
                    output = run_python_code(code, input_list)

                st.subheader("Program Output")
                st.code(output)

        # -----------------------------
        # Explain Code
        # -----------------------------
        with st.expander("📖 Explain Code"):

            if st.button("Explain Code"):

                with st.spinner("Explaining Code..."):
                    explanation = explain_code(code)

                st.write(explanation)

        # -----------------------------
        # Debug Code
        # -----------------------------
        with st.expander("🐞 Debug Code"):

            if st.button("Debug Code"):

                with st.spinner("Debugging Code..."):
                    debug = debug_code(code)

                st.write(debug)

        # -----------------------------
        # Optimize Code
        # -----------------------------
        with st.expander("⚡ Optimize Code"):

            if st.button("Optimize Code"):

                with st.spinner("Optimizing Code..."):
                    optimized = optimize_code(code)

                st.write(optimized)

        # -----------------------------
        # AI Code Review
        # -----------------------------
        with st.expander("🔍 AI Code Review"):

            if st.button("Review Code"):

                with st.spinner("Reviewing Code..."):
                    review = review_code(code)

                st.write(review)

        # -----------------------------
        # Complexity Analysis
        # -----------------------------
        with st.expander("📊 Complexity Analysis"):

            if st.button("Analyze Complexity"):

                with st.spinner("Analyzing Complexity..."):
                    complexity = analyze_complexity(code)

                st.write(complexity)

        # -----------------------------
        # Test Cases
        # -----------------------------
        with st.expander("🧪 Generate Test Cases"):

            if st.button("Generate Test Cases"):

                with st.spinner("Generating Test Cases..."):
                    tests = generate_testcases(code)

                st.write(tests)

        st.download_button(
            label="📥 Download Code",
            data=code,
            file_name=f"generated_code.{language.lower()}",
            mime="text/plain",
        )

        st.success("🎉 Analysis Completed Successfully!")

        st.balloons()
# -----------------------------
# Footer
# -----------------------------
st.markdown("---")

st.markdown(
    """
    <div class='footer' style='text-align:center; color:gray;'>
        ❤️ Thank you for using <b>AI Developer Assistant</b><br>
        Powered by <b>Google Gemini AI</b>
    </div>
    """,
    unsafe_allow_html=True,
)    