from utils import ask_gemini
from prompts import OPTIMIZE_PROMPT


def optimize_code(code):
    prompt = OPTIMIZE_PROMPT.format(code=code)
    return ask_gemini(prompt)