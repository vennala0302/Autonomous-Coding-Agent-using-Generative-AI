from prompts import CODE_PROMPT
from utils import ask_gemini


def generate_code(user_prompt, language):
    """
    Generate code using Gemini AI.
    """

    prompt = CODE_PROMPT.format(
        language=language,
        query=user_prompt
    )

    return ask_gemini(prompt)